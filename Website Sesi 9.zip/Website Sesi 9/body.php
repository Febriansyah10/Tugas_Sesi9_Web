<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Febriansyah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;700&family=Raleway:wght@500&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="style.css" />

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="tailwind.config.js"></script>
    <style type="text/tailwindcss">
      @layer utilities {
        header {
          @apply pt-5;
          background: linear-gradient(180deg, #ffffff 0%, #eaf4ff 46.08%, #ffffff 100%);
        }
        nav a {
          @apply hover:underline hover:text-primary font-nav;
        }
        .button-primary {
          @apply bg-primary text-white px-5 py-2 rounded-full;
        }
        .gradient {
          background: -webkit-linear-gradient(left, #e18700 0%, #ff32ad 50%, #0ec5d7 100%);
          color: transparent;
          background-clip: text;
        }
        .img-sponsor {
          height: 50px;
          width: auto;
          margin: 0px 25%;
        }
        .item-services {
          border: none;
          background: #ffffff;
        }
        .item {
          height: 290px;
          width: 400px;
        }
        .frame{
          margin:20%;
        }
      }
    </style>
</head>
<body>
    <!-- Sponsor -->
    <div class="sponsor mt-10 font-base mx-auto items-stretch py-14">
        <h2 class="text-center text-[#636363] my-3 leading-tight">Brands that trust us</h2>
        <div class="ml-20 mt-10 grid grid-cols-6 gap-6">
          <div class="scroll-ml-6 snap-start">
          </div>
          <div class="scroll-ml-6 snap-start"><img src="ceria.png" alt="" /></div>
          <div class="scroll-ml-6 snap-start"><img src="jfx.png" alt="" /></div>
          <div class="scroll-ml-6 snap-start"><img src="pizza.png" alt="" /></div>
          <div class="scroll-ml-6 snap-start"><img src="plant.png" alt="" /></div>
          <div class="scroll-ml-6 snap-start"><img src="rata.png" alt="" /></div>
        </div>
      </div>
  
      <!-- Services -->
      <section class="w-full pb-36 py-14 bg-gradient-to-r from-indigo-100 via-purple-100 to-pink-100">
        <div class="font-base ml-10 mt-20 flex flex-wrap item-center justify-between">
          <div class="w-[400px]">
            <h2 class="font-bold text-[35px]">Services</h2>
            <p class="w-[550px] text-[15px]">Lorem ipsum, dolor sit amet consectetur adipisicing elit. Ab sequi minima accusamus eligendi perferendis veritatis.</p>
          </div>
  
          <div>
            <button class="button-primary mr-20">Build Design</button>
          </div>
  
          <div class="w-full mx-auto grid grid-rows-2 grid-flow-col gap-4 mt-20 text-center ">
            <div class="item px-8 py-2 rounded shadow-lg shadow-indigo-500/40 flex flex-wrap items-center justify-center bg-[#ffffff]">
              <div class="w-[150px] py-10">
                <img src="shopify.png" alt="" />
              </div>
              <h1 class="font-extrabold text-lg">Shopify Theme Development</h1>
              <p class="py-4 text-sm ">Start from 700 USD for project base or 35 USD per hour</p>
            </div>
  
            <div class="item px-8 py-2 rounded shadow-lg shadow-indigo-500/40 flex flex-wrap items-center justify-center bg-[#ffffff]">
              <div class="w-[150px] py-10">
                <img src="word.png" alt="" />
              </div>
              <h1 class="font-extrabold text-lg">WordPress Theme Development</h1>
              <p class="py-4 text-sm ">Start from 600 USD for project base or 35 USD per hour</p>
            </div>
            
            <div class="item px-8 py-2 rounded shadow-lg shadow-indigo-500/40 flex flex-wrap items-center justify-center bg-[#ffffff]">
              <div class="w-[100px] h-[100px] py-10">
                <img src="php.png" alt="" />
              </div>
              <h1 class="font-extrabold text-lg">Web Application Development</h1>
              <p class="py-4 text-sm ">Start from 1000 USD for project base or 35 USD per hour</p>
            </div>
            
            <div class="item px-8 py-2 rounded shadow-lg shadow-indigo-500/40 flex flex-wrap items-center justify-center bg-[#ffffff]">
              <div class="w-[150px] py-10">
                <img src="www.png" alt="" />
              </div>
              <h1 class="font-extrabold text-lg">Custom App/Plugins Development</h1>
              <p class="py-4 text-sm ">Start from 300 USD for project base or 35 USD per hour</p>
            </div>
  
            <div class="item px-8 py-2 rounded shadow-lg shadow-indigo-500/40 flex flex-wrap items-center justify-center bg-[#ffffff]">
              <div class="w-[150px] py-10">
                <img src="assit.png" alt="" />
              </div>
              <h1 class="font-extrabold text-lg">Assistans Services</h1>
              <p class="py-4 text-sm ">Start from 33 USD for project base or 35 USD per hour</p>
            </div>
  
            <div class="item px-8 py-2 rounded shadow-lg shadow-indigo-500/40 flex flex-wrap items-center justify-center bg-[#ffffff]">
              <h1 class="font-bold text-slate-600 px-10 mt-10">More Services :</h1>
              <div class="pt-10 font-bold">
              <p>Technical Assistans</p>
              <p>Support Assistans</p>
              <p>VIP Assistans</p>
              <p>Social Media Admin</p> 
              </div>
            
            </div>
        </div>
      </section>
  
  <!-- WHAT WE DO -->
    <Section class="py-14">
      <div class="text-center justify-center ">
        <h1 class="font-bold text-[35px] ">What We Do</h1>
        <p class=" text-slate-600">Lörem ipsum patev antifili astrokålonat. Vanat aheten. Ekofiering makrora, på trekavis.</p>
        <p class=" text-slate-600">Makrona tregät plang. Bekässade kast, eftersom sore.</p>
      </div>
      <div class="grid grid-cols-4 gap-4 justify-between mx-auto items-center text-center mr-10">
        
        <div class="w-[250px] frame items-center justify-center px-3 py-2">
          <div class="px-24">
            <img src="Frame.png" alt="">
          </div>
          <h2 class="text-center font-bold text-m py-2">Design</h2>
          <p class="text-sm ">Create Wireframe Display Designs And Initial UI Designs For Websites</p>
        </div>
        <div class="w-[250px] frame items-center justify-center px-3 py-2">
          <div class="px-24">
            <img src="Frame(2).png" alt="">
          </div>
          <h2 class="text-center font-bold text-m py-2">Front End</h2>
          <p class="text-sm ">Create Wireframe Display Designs And Initial UI Designs For Websites</p>
        </div>
        <div class="w-[250px] frame items-center justify-center px-3 py-2">
          <div class="px-24">
            <img src="Frame(1).png" alt="">
          </div>
          <h2 class="text-center font-bold text-m py-2">Back End</h2>
          <p class="text-sm ">Create Wireframe Display Designs And Initial UI Designs For Websites</p>
        </div>
        <div class="w-[250px] frame items-center justify-center px-3 py-2">
          <div class="px-24">
            <img src="Frame(3).png" alt="">
          </div>
          <h2 class="text-center font-bold text-m py-2">Check Test</h2>
          <p class="text-sm ">Create Wireframe Display Designs And Initial UI Designs For Websites</p>
        </div>
      </div>
    </Section>
  
    <!-- out work -->
    <section >
      <div class="text-center justify-center pt-20">
        <h1 class="font-bold text-[35px]">Our Work</h1>
        <p class="text-slate-600">Lörem ipsum patev antifili astrokålonat. Vanat aheten. Ekofiering makrora,</p>
      </div>
      <div class="grid grid-cols-2 gap-4 py-6">
        <div class="mx-10">
          <div class="text-left">
            <img src="Frame 101.png" alt="">
          </div>
          <h1 class="font-bold text-xl py-4">Retainer Orely Studio</h1>
          <p class="text-slate-400">https://retainer.orely.co/</p>
          <div class="flex flex-wrap text-center py-4">
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">WordPress</a>
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">Tailwind</a>
          </div>
        </div>
        <div class="mx-10">
          <div class="text-left">
            <img src="Frame 102.png" alt="">
          </div>
          <h1 class="font-bold text-xl py-4">Beacukai Sangatta</h1>
          <p class="text-slate-400">https://bcsangatta.beacukai.go.id/</p>
          <div class="flex flex-wrap text-center py-4">
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">WordPress</a>
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">Tailwind</a>
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">Design</a>
          </div>
        </div>
        <div class="mx-10">
          <div class="text-left">
            <img src="Frame 101(1).png" alt="">
          </div>
          <h1 class="font-bold text-xl py-4">Federasi Ice Skating Indonesia</h1>
          <p class="text-slate-400">https://fisid.org/</p>
          <div class="flex flex-wrap text-center py-4">
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">WordPress</a>
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">Tailwind</a>
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">Design</a>
          </div>
        </div>
        <div class="mx-10">
          <div class="text-left">
            <img src="Frame 101.png" alt="">
          </div>
          <h1 class="font-bold text-xl py-4">Retainer Orely Studio</h1>
          <p class="text-slate-400">https://retainer.orely.co/</p>
          <div class="flex flex-wrap text-center py-4">
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">WordPress</a>
            <a href="#" class="border-solid border-2 border-indigo-300 w-28 h-10 mr-4 pt-1">Tailwind</a>
          </div>
        </div>
      </div>
      <div class="mb-5 action flex mx-auto justify-center items-center gap-5">
        <a href="#" class="button-primary">Our Work</a>
        </div>
    </section>
  
  <!-- kata kata -->
  <section class="my-32 bg-[#F6F9FC]">
    <div class="text-center justify-center py-20">
      <h1 class="font-bold text-[35px]"><span class="gradient"> What people say about</span> <br>
        Mangcoding Team?</h1>
        <p class="ml-80 w-[700px] text-[30px] py-14 ">“ It was a great experience to work with Mangcoding, we love the details result, and professionalism.
          “</p>
          <div class="mb-5 action flex mx-auto justify-center items-center gap-5">
            <img src="image 16.png" alt="">
          </div>
          <h2 class="font-bold text-lg">Riko Sapto Dimo </h2>
          <p class="text-slate-600">Managing Director Orely.co</p>
          <div class="radio-1 pt-10">
            <input type="radio" name="radio-1">
            <input type="radio" name="radio-1">
            <input type="radio" name="radio-1">
          </div>
        </div>
    </section>
  
    <!-- our blog -->
  
    <section class="pb-20">
      <div class="text-center justify-center">
        <h1 class="font-bold text-[35px]">Our Blog</h1>
      </div>
      <div class="grid grid-cols-3 gap-1 py-10 mx-20">
        <div class="mx-1">
          <div class="">
            <img src="image 19.png" alt="">
          </div>
          <p class="font-bold text-[20px]">8 Alasan Pentingnya Melakukan Pencadangan Situs Web</p>
        </div>
        <div class="">
          <div class="">
            <img src="image 20.png" alt="">
          </div>
          <p class="font-bold text-[20px]">8 Alasan Pentingnya Melakukan Pencadangan Situs Web</p>
        </div>
        <div class="">
          <div class="">
            <img src="image 21.png" alt="">
          </div>
          <p class="font-bold text-[20px]">8 Alasan Pentingnya Melakukan Pencadangan Situs Web</p>
        </div>
      </div>
      <div class="mb-5 action flex mx-auto justify-center items-center gap-5">
        <a href="#" class="button-primary">Our Work</a>
        </div>
    </section>
  
    <!-- sebelum footer -->
    <section class="py-10 bg-gradient-to-r from-indigo-200 via-purple-200 to-pink-200">
      <div class="font-base mx-16 mt-20 flex flex-wrap item-center justify-between">
        <div class="">
          <h2 class="font-bold text-[35px]">Let's build a website with mangcoding</h2>
          <p class="w-[550px] text-[15px]">Mangcoding team will help you in branding your product</p>
        </div>
  
        <div>
          <button class="button-primary mr-20">Build Website Now</button>
        </div>
    </section>
    </body>
  </html>
</body>
</html>
