<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Febriansyah</title>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@300;400;700&family=Raleway:wght@500&display=swap" rel="stylesheet" />
    <link rel="stylesheet" href="style.css" />

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="tailwind.config.js"></script>
    <style type="text/tailwindcss">
      @layer utilities {
        header {
          @apply pt-5;
          background: linear-gradient(180deg, #ffffff 0%, #eaf4ff 46.08%, #ffffff 100%);
        }
        nav a {
          @apply hover:underline hover:text-primary font-nav;
        }
        .button-primary {
          @apply bg-primary text-white px-5 py-2 rounded-full;
        }
        .gradient {
          background: -webkit-linear-gradient(left, #e18700 0%, #ff32ad 50%, #0ec5d7 100%);
          color: transparent;
          background-clip: text;
        }
        .img-sponsor {
          height: 50px;
          width: auto;
          margin: 0px 25%;
        }
        .item-services {
          border: none;
          background: #ffffff;
        }
        .item {
          height: 290px;
          width: 400px;
        }
        .frame{
          margin:20%;
        }
      }
    </style>
</head>
<body>
    <footer class="my-20">
      <div class="flex flex-wrap">
        <div class="mx-10 w-[300px]">
          <div class="flex flex-wrap py-10">
            <img src="Group 2.png" alt="">
          </div>
          <p class="text-slate-400">Mangcoding Team Will Help You In Branding Your Product  asdMangcoding Team Will Help You In Branding Your Product asdMangcoding Team Will Help.</p>
          <div class="flex flex-wrap py-10" >
            <img src="1 (1).png" alt="" class="mr-4">
            <img src="1 (2).png" alt="" class="mr-4">
            <img src="1 (3).png" alt="" class="mr-4">
            <img src="1 (4).png" alt="" class="mr-4">
          </div>
        </div>
        <div class="mt-10 ">
          <h2 class="font-bold text-lg">Mangcoding</h2>
          <ul class="py-6 text-slate-400">
            <li class="pb-6"><a href="#">Home</a></li>
            <li class="pb-6"><a href="#">About</a></li>
            <li class="pb-6"><a href="#">Services</a></li>
            <li class="pb-6"><a href="#">Blog</a></li>
            <li class="pb-6"><a href="#">Contact</a></li>
          </ul>
        </div>
        <div class="mt-10 ml-12">
          <h2 class="font-bold text-lg">Services</h2>
          <ul class="py-6 text-slate-400">
            <li class="pb-6"><a href="#">Custom WordPress Theme Development </a></li>
            <li class="pb-6"><a href="#">Custom Plugin WordPress </a></li>
            <li class="pb-6"><a href="#">Custom Shopify Theme Development </a></li>
            <li class="pb-6"><a href="#">Custom App for Shopify</a></li>
            <li class="pb-6"><a href="#">Web Application</a></li>
          </ul>
        </div>
        <div class="mt-10 ml-12">
          <h2 class="font-bold text-lg">Trusted partner</h2>
          <div class="py-4">
            <img src="orely.png" alt="" class="pb-4">
            <img src="kiwa.png" alt="">
          </div>
        </div>
        <div class="mt-10 ml-12">
          <h2 class="font-bold text-lg">Services</h2>
          <div class="w-[300px] py-4">
            <a href="#"><img src="  " alt="">hello@mangcoding.com</a>
            <a href="#"><img class="flex justify-between items-center" src="tlp.png" alt="">0266-6532078<br>WA:0857-5940-2332</a>
            <a href="#" ><img src="gps.png" alt="">PT Anugrah Kreasi Digital. karang <br> tengah, Cibadak - Sukabumi</a>
          </div>
        </div>
      </div>
    </footer>
    </body>
  </html>
</body>
</html>
